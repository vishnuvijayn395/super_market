const STORAGE_KEY = "kakde_products";
const MAX_FILE_SIZE_MB = 2; // keep small for localStorage safety

const els = {
  form: document.getElementById("productForm"),
  formTitle: document.getElementById("formTitle"),
  id: document.getElementById("productId"),
  name: document.getElementById("name"),
  category: document.getElementById("category"),
  meta: document.getElementById("meta"),
  image: document.getElementById("image"),
  imageFile: document.getElementById("imageFile"),
  price: document.getElementById("price"),
  mrp: document.getElementById("mrp"),
  discount: document.getElementById("discount"),
  resetBtn: document.getElementById("resetBtn"),
  tableWrap: document.getElementById("tableWrap"),
  search: document.getElementById("searchAdmin"),
};

function getProducts() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error("Read error:", e);
    return [];
  }
}

function saveProducts(products) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
    return true;
  } catch (e) {
    console.error("Save error:", e);
    alert("Save failed. Image may be too large for browser storage. Use smaller image or image URL.");
    return false;
  }
}

function resetForm() {
  els.form.reset();
  els.id.value = "";
  els.formTitle.textContent = "Add Product";
}

function fillForm(p) {
  els.id.value = p.id;
  els.name.value = p.name || "";
  els.category.value = p.category || "";
  els.meta.value = p.meta || "";
  els.image.value = p.image && !p.image.startsWith("data:") ? p.image : "";
  els.price.value = p.price ?? "";
  els.mrp.value = p.mrp ?? "";
  els.discount.value = p.discount ?? "";
  els.formTitle.textContent = "Edit Product";
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function isValidImageFile(file) {
  const allowed = ["image/png", "image/jpeg", "image/jpg", "image/webp"];
  return allowed.includes(file.type);
}

function escapeHtml(str = "") {
  return str
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderTable() {
  const q = (els.search.value || "").toLowerCase().trim();
  const products = getProducts().filter((p) =>
    `${p.name || ""} ${p.category || ""} ${p.meta || ""}`.toLowerCase().includes(q)
  );

  if (!products.length) {
    els.tableWrap.innerHTML = `<div class="empty">No products found.</div>`;
    return;
  }

  els.tableWrap.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Image</th>
          <th>Product</th>
          <th>Category</th>
          <th>Price</th>
          <th>MRP</th>
          <th>Discount</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${products.map((p) => `
          <tr>
            <td>
              <img class="img-preview"
                   src="${escapeHtml(p.image || "https://via.placeholder.com/60x60?text=No+Img")}"
                   alt="${escapeHtml(p.name || "Product")}">
            </td>
            <td>${escapeHtml(p.name || "")}<br><small>${escapeHtml(p.meta || "")}</small></td>
            <td><span class="tag">${escapeHtml(p.category || "")}</span></td>
            <td>₹${Number(p.price || 0)}</td>
            <td>₹${Number(p.mrp || 0)}</td>
            <td>${Number(p.discount || 0)}%</td>
            <td>
              <div class="row-actions">
                <button class="btn edit" data-edit="${p.id}">Edit</button>
                <button class="btn danger" data-delete="${p.id}">Delete</button>
              </div>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

els.form.addEventListener("submit", async (e) => {
  e.preventDefault();

  try {
    let imageValue = (els.image.value || "").trim();
    const file = els.imageFile.files?.[0];

    if (file) {
      if (!isValidImageFile(file)) {
        alert("Please upload PNG/JPG/WEBP image only.");
        return;
      }

      const maxBytes = MAX_FILE_SIZE_MB * 1024 * 1024;
      if (file.size > maxBytes) {
        alert(`Image is too large. Please use file under ${MAX_FILE_SIZE_MB}MB.`);
        return;
      }

      imageValue = await fileToBase64(file);
    }

    if (!imageValue) {
      alert("Please provide image URL or upload image.");
      return;
    }

    const product = {
      id: els.id.value || crypto.randomUUID(),
      name: (els.name.value || "").trim(),
      category: (els.category.value || "").trim(),
      meta: (els.meta.value || "").trim(),
      image: imageValue,
      price: Number(els.price.value),
      mrp: Number(els.mrp.value),
      discount: Number(els.discount.value),
    };

    if (!product.name || !product.category || !product.meta) {
      alert("Please fill all text fields.");
      return;
    }
    if (product.price <= 0 || product.mrp <= 0) {
      alert("Price and MRP must be greater than 0.");
      return;
    }
    if (product.price > product.mrp) {
      alert("Price should be less than or equal to MRP.");
      return;
    }
    if (product.discount < 0 || product.discount > 90) {
      alert("Discount must be between 0 and 90.");
      return;
    }

    const products = getProducts();
    const idx = products.findIndex((p) => p.id === product.id);
    if (idx >= 0) products[idx] = product;
    else products.unshift(product);

    const ok = saveProducts(products);
    if (!ok) return;

    resetForm();
    renderTable();
    alert("Product saved successfully ✅");
  } catch (err) {
    console.error(err);
    alert("Something went wrong while saving. Check console for details.");
  }
});

els.tableWrap.addEventListener("click", (e) => {
  const editId = e.target.getAttribute("data-edit");
  const delId = e.target.getAttribute("data-delete");
  const products = getProducts();

  if (editId) {
    const p = products.find((x) => x.id === editId);
    if (p) fillForm(p);
  }

  if (delId) {
    if (!confirm("Delete this product?")) return;
    const updated = products.filter((x) => x.id !== delId);
    const ok = saveProducts(updated);
    if (!ok) return;
    renderTable();
  }
});

els.resetBtn.addEventListener("click", resetForm);
els.search.addEventListener("input", renderTable);

// first render
renderTable();