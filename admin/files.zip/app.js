const STORAGE_KEY = "kakde_products";
let cartCount = 0;

const cartCountEl = document.getElementById("cartCount");
const productGrid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const allCatBtn = document.getElementById("allCatBtn");
const catDropdown = document.getElementById("catDropdown");
const navLinks = [...document.querySelectorAll(".navlink")];

const offersTrack = document.getElementById("offersTrack");
const offersPrev = document.getElementById("offersPrev");
const offersNext = document.getElementById("offersNext");
const offersDots = document.getElementById("offersDots");
let currentOffer = 0;
let offerTimer = null;

const defaultProducts = [
  { id:"1", name:"Amul Taaza Milk", category:"Milk & Dairy", meta:"1 Ltr", image:"https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=500&q=80", price:61, mrp:68, discount:10 },
  { id:"2", name:"Aashirvaad Atta", category:"Staples & Grains", meta:"5 Kg", image:"https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=500&q=80", price:239, mrp:280, discount:15 },
  { id:"3", name:"Fortune Sunflower Oil", category:"Cooking Essentials", meta:"1 Ltr", image:"https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=500&q=80", price:135, mrp:146, discount:8 },
  { id:"4", name:"Tata Tea Premium", category:"Beverages", meta:"1 Kg", image:"https://images.unsplash.com/photo-1597318181409-cf64d0b5d8a2?auto=format&fit=crop&w=500&q=80", price:530, mrp:590, discount:10 }
];

function getProducts(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if(!raw){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultProducts));
    return defaultProducts;
  }
  try { return JSON.parse(raw) || []; } catch { return []; }
}

function setCartCount(n){ cartCount=n; cartCountEl.textContent=String(n); }

function renderProducts(list){
  if(!list.length){
    productGrid.innerHTML = `<div class="no-results">No products found. Try another keyword.</div>`;
    return;
  }
  productGrid.innerHTML = list.map(p=>`
    <article class="card product" data-name="${p.name}">
      <div class="product__tag">${p.discount}% OFF</div>
      <div class="product__img"><img src="${p.image}" alt="${p.name}" loading="lazy"></div>
      <h3 class="product__name">${p.name}</h3>
      <p class="product__meta">${p.meta}</p>
      <div class="product__price"><span class="price">₹${p.price}</span><span class="mrp">₹${p.mrp}</span></div>
      <button class="btn btn--yellow addToCart">Add to cart</button>
    </article>
  `).join("");
}

function filterProducts(){
  const q = (searchInput.value||"").toLowerCase().trim();
  const all = getProducts();
  const filtered = all.filter(p => `${p.name} ${p.meta} ${p.category}`.toLowerCase().includes(q));
  renderProducts(filtered);
}

productGrid.addEventListener("click", (e)=>{
  const btn = e.target.closest(".addToCart");
  if(!btn) return;
  setCartCount(cartCount+1);
  btn.textContent = "Added!";
  btn.disabled = true;
  setTimeout(()=>{ btn.textContent="Add to cart"; btn.disabled=false; }, 600);
});

searchBtn.addEventListener("click", filterProducts);
searchInput.addEventListener("input", filterProducts);
searchInput.addEventListener("keydown",(e)=>{ if(e.key==="Enter"){ e.preventDefault(); filterProducts(); }});

allCatBtn.addEventListener("click",(e)=>{
  e.preventDefault(); e.stopPropagation();
  catDropdown.toggleAttribute("hidden");
});
catDropdown.addEventListener("click",(e)=>e.stopPropagation());
document.addEventListener("click",()=>catDropdown.setAttribute("hidden",""));

function getHeaderOffset(){ return (document.querySelector(".header")?.offsetHeight||0)+10; }
function activateNav(hash){
  navLinks.forEach(l=>l.classList.remove("is-active"));
  const m = navLinks.find(l=>l.getAttribute("href")===hash) || navLinks[0];
  if(m) m.classList.add("is-active");
}
function scrollToHash(hash){
  if(hash==="#"||!hash){ window.scrollTo({top:0,behavior:"smooth"}); activateNav("#"); return; }
  const el = document.querySelector(hash); if(!el) return;
  const top = el.getBoundingClientRect().top + window.scrollY - getHeaderOffset();
  window.scrollTo({top, behavior:"smooth"}); activateNav(hash);
}
navLinks.forEach(link=>{
  link.addEventListener("click",(e)=>{
    const href = link.getAttribute("href");
    if(!href?.startsWith("#")) return;
    e.preventDefault();
    scrollToHash(href);
  });
});

/* Offers slider */
function buildDots(){
  if(!offersTrack) return;
  const total = offersTrack.children.length;
  offersDots.innerHTML = "";
  for(let i=0;i<total;i++){
    const b = document.createElement("button");
    b.addEventListener("click",()=>goOffer(i));
    offersDots.appendChild(b);
  }
}
function goOffer(i){
  const total = offersTrack.children.length;
  currentOffer = (i+total)%total;
  offersTrack.style.transform = `translateX(-${currentOffer*100}%)`;
  [...offersDots.children].forEach((d,idx)=>d.classList.toggle("active", idx===currentOffer));
}
function nextOffer(){ goOffer(currentOffer+1); }
function prevOffer(){ goOffer(currentOffer-1); }

offersNext?.addEventListener("click", nextOffer);
offersPrev?.addEventListener("click", prevOffer);

function startAuto(){
  clearInterval(offerTimer);
  offerTimer = setInterval(nextOffer, 3200);
}

setCartCount(0);
renderProducts(getProducts());
buildDots();
goOffer(0);
startAuto();